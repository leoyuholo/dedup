/**
 * 
 */
package com.rackspacecloud.client.cloudfiles;

/**
 * @author lvaughn
 *
 */
public interface IFilesTransferCallback {
	public void progress(long n);

}
